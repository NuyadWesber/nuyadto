<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// ---------------------------
// Default Route
// ---------------------------
$routes->get('/', 'Auth::login'); // Login page as default

// ---------------------------
// Authentication Routes
// ---------------------------
$routes->group('admin', function ($routes) {
    $routes->get('login', 'Auth::login');
    $routes->get('register', 'Auth::register');
    $routes->post('store', 'Auth::store');
    $routes->post('authenticate', 'Auth::authenticate');
    $routes->get('logout', 'Auth::logout');
});

// ---------------------------
// Task Management Routes
// ---------------------------
$routes->get('/tasks', 'TaskController::index'); // View tasks (everyone)

$routes->group('task', function ($routes) {
    $routes->get('create', 'TaskController::create');          // Only for admin (we'll check in controller)
    $routes->post('store', 'TaskController::store');           // Only for admin
    $routes->get('edit/(:num)', 'TaskController::edit/$1');    // Only for admin
    $routes->post('update/(:num)', 'TaskController::update/$1'); // Only for admin
    $routes->get('delete/(:num)', 'TaskController::delete/$1'); // Only for admin
});

// ---------------------------
// Upload Route
// ---------------------------
$routes->post('upload', 'UploadController::upload');

// ---------------------------
// Optional Dashboard
// ---------------------------
$routes->get('dashboard', 'Dashboard::index');

// ---------------------------
// RESTful API Routes (Optional)
// ---------------------------
$routes->group('api', ['namespace' => 'App\Controllers\Api'], function($routes) {
    $routes->get('tasks', 'TaskApiController::index');
    $routes->get('tasks/(:num)', 'TaskApiController::show/$1');
    $routes->post('tasks', 'TaskApiController::create');
    $routes->put('tasks/(:num)', 'TaskApiController::update/$1');
    $routes->delete('tasks/(:num)', 'TaskApiController::delete/$1');
});
