<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Task | RecoverEase</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: url('<?= base_url("assets/images/ntc.jpg") ?>') no-repeat center center fixed;
            background-size: cover;
            padding: 40px;
        }

        .container {
            background-color: rgba(255, 255, 255, 0.96);
            max-width: 600px;
            margin: auto;
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
        }

        .header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 25px;
        }

        .header img {
            height: 50px;
            object-fit: contain;
        }

        .header h2 {
            font-size: 24px;
            font-weight: 700;
            color: #0c3c85;
            flex: 1;
            text-align: center;
        }

        label {
            font-weight: 500;
            display: block;
            margin-bottom: 8px;
            font-size: 15px;
        }

        input[type="text"],
        input[type="date"],
        select {
            width: 100%;
            padding: 12px 14px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 15px;
        }

        input:focus,
        select:focus {
            border-color: #0c3c85;
            outline: none;
            box-shadow: 0 0 0 2px rgba(12, 60, 133, 0.2);
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #0c3c85;
            color: #fff;
            font-size: 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #092b61;
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #0c3c85;
            text-decoration: none;
            font-size: 14px;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <img src="<?= base_url('assets/images/ntc1.jpg') ?>" alt="NTC Logo" onerror="this.onerror=null; this.src='<?= base_url('assets/images/ntc1.JPG') ?>';">
            <h2>Add New Task</h2>
        </div>

        <form action="<?= base_url('task/store') ?>" method="post">
            <label for="title">Task Title</label>
            <input type="text" id="title" name="title" placeholder="e.g., Return Found ID" required>

            <label for="priority">Priority</label>
            <select id="priority" name="priority" required>
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
            </select>

            <label for="deadline">Deadline</label>
            <input type="date" id="deadline" name="deadline" required>

            <label for="assigned_to">Assigned To</label>
            <input type="text" id="assigned_to" name="assigned_to" placeholder="e.g., John Dela Cruz" required>

            <button type="submit">Save Task</button>
        </form>

        <a href="<?= base_url('tasks') ?>" class="back-link">← Back to Task List</a>
    </div>
</body>
</html>
