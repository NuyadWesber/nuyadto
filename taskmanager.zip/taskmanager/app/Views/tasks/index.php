<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Task Manager</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap');

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: url('<?= base_url('assets/images/ntc.jpg') ?>') no-repeat center center fixed;
            background-size: cover;
            color: #2c3e50;
            padding: 40px;
        }

        /* Flash messages */
        .alert-box,
        .alert-box-success {
            max-width: 600px;
            margin: 0 auto 20px auto;
            text-align: center;
            padding: 12px 20px;
            font-weight: bold;
            border-radius: 8px;
        }

        .alert-box {
            background-color: #e74c3c;
            color: white;
        }

        .alert-box-success {
            background-color: #27ae60;
            color: white;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: rgba(255, 255, 255, 0.95);
            padding: 20px 30px;
            border-radius: 16px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        .logo-title {
            display: flex;
            align-items: center;
        }

        .logo-title img {
            height: 80px;
            margin-right: 20px;
        }

        .logo-title h1 {
            font-size: 32px;
            color: #0c3c85;
        }

        .actions button {
            padding: 10px 16px;
            margin-left: 10px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background-color: #0c3c85;
            color: white;
        }

        .btn-primary:hover {
            background-color: #185bb5;
            transform: scale(1.05);
        }

        .btn-danger {
            background-color: #e74c3c;
            color: white;
        }

        .btn-danger:hover {
            background-color: #ff6f61;
            transform: scale(1.05);
        }

        .upload-box {
            background: white;
            border-left: 6px solid #f1c40f;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 30px;
            backdrop-filter: blur(4px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.05);
        }

        .upload-box input[type="file"] {
            margin-right: 10px;
        }

        .upload-box button {
            background-color: #27ae60;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s ease;
        }

        .upload-box button:hover {
            background-color: #2ecc71;
            transform: scale(1.05);
        }

        .tasks-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
        }

        .task-card {
            background-color: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.05);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .task-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 24px rgba(0,0,0,0.12);
        }

        .task-card h3 {
            color: #0c3c85;
            margin-bottom: 8px;
        }

        .task-info {
            margin-bottom: 10px;
            font-size: 14px;
            color: #555;
        }

        .task-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }

        .task-actions a {
            text-decoration: none;
            color: #0c3c85;
            font-weight: 600;
            transition: color 0.2s ease;
        }

        .task-actions a:hover {
            color: #185bb5;
            text-decoration: underline;
        }

        @media (max-width: 600px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
            }

            .header .actions {
                margin-top: 10px;
            }

            .logo-title {
                margin-bottom: 15px;
            }
        }
    </style>
</head>
<body>

    <!-- Flash Messages -->
    <?php if (session()->getFlashdata('error')): ?>
        <div class="alert-box">
            <?= esc(session()->getFlashdata('error')) ?>
        </div>
    <?php endif; ?>

    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert-box-success">
            <?= esc(session()->getFlashdata('success')) ?>
        </div>
    <?php endif; ?>

    <!-- Header -->
    <div class="header">
        <div class="logo-title">
            <img src="<?= base_url('assets/images/ntc1.jpg') ?>" alt="NTC Logo">
            <h1>Task Dashboard</h1>
        </div>
        <div class="actions">
            <a href="<?= base_url('task/create') ?>"><button class="btn-primary">+ Add Task</button></a>
            <a href="<?= base_url('admin/logout') ?>"><button class="btn-danger">Logout</button></a>
        </div> 
    </div>

    <!-- Upload Box -->
    <div class="upload-box">
        <form action="<?= base_url('upload') ?>" method="post" enctype="multipart/form-data">
            <label>Upload File (JPG, PNG, PDF):</label><br><br>
            <input type="file" name="file" required>
            <button type="submit">Upload</button>
        </form>
    </div>

    <!-- Task Grid -->
    <div class="tasks-grid">
        <?php foreach ($tasks as $task): ?>
            <div class="task-card">
                <div>
                    <h3><?= esc($task['title']) ?></h3>
                    <div class="task-info"><strong>Priority:</strong> <?= esc($task['priority']) ?></div>
                    <div class="task-info"><strong>Deadline:</strong> <?= esc($task['deadline']) ?></div>
                    <div class="task-info"><strong>Status:</strong> <?= esc($task['status']) ?></div>
                    <div class="task-info"><strong>Assigned To:</strong> <?= esc($task['assigned_to']) ?></div>
                </div>
                <div class="task-actions">
                    <a href="<?= base_url('task/edit/' . $task['id']) ?>">Edit</a>
                    <a href="<?= base_url('task/delete/' . $task['id']) ?>" onclick="return confirm('Delete this task?')">Delete</a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

</body>
</html>
