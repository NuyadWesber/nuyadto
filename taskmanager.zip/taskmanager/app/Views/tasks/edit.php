<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Task | Task Manager</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: url('<?= base_url('assets/images/ntc.jpg') ?>') no-repeat center center fixed;
            background-size: cover;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .form-container {
            background-color: rgba(255, 255, 255, 0.96);
            width: 900px;
            padding: 40px 50px;
            border-radius: 16px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
            display: flex;
            flex-direction: column;
        }

        .logo {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .logo img {
            height: 90px;
            width: auto;
        }

        h2 {
            text-align: center;
            font-size: 28px;
            font-weight: 700;
            color: #0c3c85;
            margin-bottom: 30px;
        }

        form {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: space-between;
        }

        .form-group {
            flex: 1 1 45%;
            display: flex;
            flex-direction: column;
        }

        .form-group.full {
            flex: 1 1 100%;
        }

        label {
            font-weight: 500;
            margin-bottom: 6px;
            font-size: 15px;
            color: #333;
        }

        input[type="text"],
        input[type="date"],
        select,
        textarea {
            padding: 10px 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        textarea {
            resize: vertical;
            min-height: 80px;
        }

        input:focus,
        select:focus,
        textarea:focus {
            border-color: #0c3c85;
            outline: none;
            box-shadow: 0 0 0 2px rgba(12, 60, 133, 0.15);
        }

        button {
            width: 100%;
            padding: 14px;
            background-color: #0c3c85;
            color: #fff;
            font-size: 16px;
            font-weight: 600;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 10px;
        }

        button:hover {
            background-color: #185bb5;
            transform: scale(1.02);
        }

        .back-link {
            text-align: center;
            margin-top: 20px;
            color: #0c3c85;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .back-link:hover {
            text-decoration: underline;
            color: #092b61;
        }

        @media (max-width: 950px) {
            .form-container {
                width: 95%;
                padding: 30px 20px;
            }

            .form-group {
                flex: 1 1 100%;
            }

            h2 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>

<div class="form-container">
    <div class="logo">
        <img src="<?= base_url('assets/images/ntc1.jpg') ?>" alt="NTC Logo">
    </div>

    <h2>Edit Task</h2>

    <form method="post" action="<?= base_url('task/update/' . $task['id']) ?>">
        <?= csrf_field(); ?>

        <div class="form-group">
            <label for="title">Title</label>
            <input type="text" name="title" value="<?= old('title', $task['title']); ?>" required>
        </div>

        <div class="form-group">
            <label for="assigned_to">Assigned To</label>
            <input type="text" name="assigned_to" value="<?= old('assigned_to', $task['assigned_to']); ?>">
        </div>

        <div class="form-group">
            <label for="priority">Priority</label>
            <select name="priority" required>
                <option value="low" <?= $task['priority'] == 'low' ? 'selected' : ''; ?>>Low</option>
                <option value="medium" <?= $task['priority'] == 'medium' ? 'selected' : ''; ?>>Medium</option>
                <option value="high" <?= $task['priority'] == 'high' ? 'selected' : ''; ?>>High</option>
            </select>
        </div>

        <div class="form-group">
            <label for="status">Status</label>
            <select name="status">
                <option value="pending" <?= $task['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                <option value="in_progress" <?= $task['status'] == 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
                <option value="completed" <?= $task['status'] == 'completed' ? 'selected' : ''; ?>>Completed</option>
            </select>
        </div>

        <div class="form-group">
            <label for="deadline">Deadline</label>
            <input type="date" name="deadline" value="<?= old('deadline', $task['deadline']); ?>" required>
        </div>

        <div class="form-group full">
            <label for="description">Description</label>
            <textarea name="description"><?= old('description', $task['description']); ?></textarea>
        </div>

        <div class="form-group full">
            <button type="submit">Save Changes</button>
        </div>
    </form>

    <a href="<?= base_url('tasks') ?>" class="back-link">← Back to Task List</a>
</div>

</body>
</html>
