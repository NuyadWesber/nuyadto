<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap');

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            font-family: 'Inter', sans-serif;
            background: url('<?= base_url("assets/images/ntc.jpg") ?>') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            position: relative;
        }

        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.6); /* White overlay */
            z-index: 0;
        }

        .register-container {
            position: relative;
            z-index: 1;
            background-color: #ffffffdd;
            padding: 40px 30px;
            border-radius: 16px;
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 420px;
            backdrop-filter: blur(6px);
        }

        h2 {
            margin-bottom: 24px;
            color: #2c3e50;
            font-size: 28px;
            text-align: center;
        }

        input[type="text"],
        input[type="password"],
        select {
            width: 100%;
            padding: 14px;
            margin-bottom: 20px;
            border: 1px solid #dcdde1;
            border-radius: 10px;
            font-size: 16px;
            background-color: #f9f9f9;
        }

        input:focus,
        select:focus {
            border-color: #74b9ff;
            background-color: #fff;
            outline: none;
        }

        button {
            width: 100%;
            padding: 14px;
            background-color: #0984e3;
            color: #fff;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #74b9ff;
        }

        .error-message {
            color: #d63031;
            font-size: 14px;
            margin-bottom: 20px;
            text-align: center;
        }

        .login-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #0984e3;
            text-decoration: none;
        }

        .login-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="register-container">
    <h2>Register</h2>
    <?php if (session()->getFlashdata('error')): ?>
        <div class="error-message"><?= session()->getFlashdata('error') ?></div>
    <?php endif; ?>
    <form action="<?= base_url('admin/store') ?>" method="post">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>

        <select name="role" required>
            <option value="" disabled selected>Select Your Role Type</option>
            <option value="admin">Admin</option>
            <option value="user">User</option>
        </select>

        <button type="submit">Register</button>
    </form>
    <a href="<?= base_url('admin/login') ?>" class="login-link">Already have an account? Login here.</a>
</div>

</body>
</html>
