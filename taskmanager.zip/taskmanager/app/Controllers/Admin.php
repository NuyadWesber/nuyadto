<?php

namespace App\Controllers;

use App\Models\AdminModel;
use App\Models\UserModel;

class Admin extends BaseController
{
    public function login()
    {
        return view('admin/login');
    }

    public function authenticate()
    {
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        // Try login as Admin
        $adminModel = new AdminModel();
        $admin = $adminModel->where('username', $username)->first();

        if ($admin && password_verify($password, $admin['password'])) {
            session()->set([
                'id' => $admin['id'],
                'username' => $admin['username'],
                'role' => 'admin',
                'user_logged_in' => true
            ]);
            return redirect()->to('/tasks');
        }

        // Try login as regular user
        $userModel = new UserModel();
        $user = $userModel->where('username', $username)->first();

        if ($user && password_verify($password, $user['password'])) {
            session()->set([
                'id' => $user['id'],
                'username' => $user['username'],
                'role' => 'user',
                'user_logged_in' => true
            ]);
            return redirect()->to('/tasks');
        }

        // Invalid credentials
        return redirect()->to('/admin/login')->with('error', 'Invalid username or password');
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/admin/login');
    }

    public function register()
    {
        return view('admin/register');
    }

    public function store()
    {
        $userModel = new \App\Models\UserModel();

        $data = [
            'username' => $this->request->getPost('username'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT)
        ];

        $userModel->save($data);
        return redirect()->to('/admin/login')->with('success', 'Registration successful');
    }
}
