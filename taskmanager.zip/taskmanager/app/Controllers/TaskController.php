<?php

namespace App\Controllers;
use App\Models\TaskModel;

class TaskController extends BaseController
{
    public function index()
    {
        if (!session()->get('user_logged_in')) {
            return redirect()->to('/admin/login')->with('error', 'Please log in.');
        }

        $model = new TaskModel();
        $role = session()->get('role');

        // ✅ Everyone sees all tasks — no filters
        $data['tasks'] = $model->findAll();

        $data['role'] = $role; // Used in the view to hide edit/delete buttons for users
        return view('tasks/index', $data);
    }

    public function create()
    {
        if (!$this->isAdmin()) {
            return redirect()->to('/tasks')->with('error', 'Only admins can create tasks.');
        }

        return view('tasks/create');
    }

    public function store()
    {
        if (!$this->isAdmin()) {
            return redirect()->to('/tasks')->with('error', 'Only admins can store tasks.');
        }

        $model = new TaskModel();

        $data = [
            'title' => $this->request->getPost('title'),
            'priority' => $this->request->getPost('priority'),
            'deadline' => $this->request->getPost('deadline'),
            'assigned_to' => $this->request->getPost('assigned_to') ?? null,
        ];

        $model->save($data);
        return redirect()->to('/tasks')->with('success', 'Task created successfully.');
    }

    public function edit($id)
    {
        if (!$this->isAdmin()) {
            return redirect()->to('/tasks')->with('error', 'Only admins can edit tasks.');
        }

        $model = new TaskModel();
        $task = $model->find($id);

        if (!$task) {
            return redirect()->to('/tasks')->with('error', 'Task not found.');
        }

        return view('tasks/edit', ['task' => $task]);
    }

    public function update($id)
    {
        if (!$this->isAdmin()) {
            return redirect()->to('/tasks')->with('error', 'Only admins can update tasks.');
        }

        $model = new TaskModel();

        $updatedData = [
            'title' => $this->request->getPost('title'),
            'priority' => $this->request->getPost('priority'),
            'deadline' => $this->request->getPost('deadline'),
            'assigned_to' => $this->request->getPost('assigned_to') ?? null,
        ];

        $model->update($id, $updatedData);

        return redirect()->to('/tasks')->with('success', 'Task updated successfully.');
    }

    public function delete($id)
    {
        if (!$this->isAdmin()) {
            return redirect()->to('/tasks')->with('error', 'Only admins can delete tasks.');
        }

        $model = new TaskModel();
        $task = $model->find($id);

        if ($task) {
            $model->delete($id);
        }

        return redirect()->to('/tasks')->with('success', 'Task deleted successfully.');
    }

    private function isAdmin()
    {
        return session()->get('role') === 'admin';
    }
}
